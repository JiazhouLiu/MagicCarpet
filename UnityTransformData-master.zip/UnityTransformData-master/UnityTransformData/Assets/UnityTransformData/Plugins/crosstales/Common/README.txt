﻿# crosstales LLC - Common package 2019.4.0

## Description
This folder and its content is needed for all assets from "crosstales LLC".

Please DON'T DELETE anything except "Prefabs" and "UI" or the assets won't work anymore!



## Contact

crosstales LLC
Schanzeneggstrasse 1
CH-8002 Zürich

* [Homepage](https://www.crosstales.com/)
* [Email](mailto:assets@crosstales.com)

### Social media
* [Facebook](https://www.facebook.com/crosstales/)
* [Twitter](https://twitter.com/crosstales)
* [LinkedIN](https://www.linkedin.com/company/crosstales)



## More information
* [AssetStore](https://goo.gl/qwtXyb)
* [Youtube-channel](https://www.youtube.com/c/Crosstales)


`Version: 25.07.2019`